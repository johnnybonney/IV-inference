library(testthat)
library(mst)

test_check("mst")
